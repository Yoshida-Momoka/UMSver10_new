package servlet;

/*
 *プログラム名  ：ユニフォーム発注管理システム
 *プログラム説明：購入情報を処理を提供するサーブレット
 *作成者        ：小倉悠聖
 *作成日        ：2024年1月31日
 *変更履歴      ：STEP1 初期作成
 */

import java.io.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;
import util.SendMail;
import util.MyFormat;
import dao.OrderDAO;
import dao.ProductDAO;
import bean.Order;
import bean.User;
import bean.Sales;

public class BuyConfirmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {

			//  セッションから"user"を取得する
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// セッション切れの場合はerror.jspに遷移する
			if (user == null) {
				error = "セッション切れの為、購入は出来ません。";
				cmd = "login";
				return;
			}

			//  セッションからorder_listを取得する
			ArrayList<Order> order_list = (ArrayList<Order>) session.getAttribute("order_data");

			// カートの中身がない場合はerror.jspに遷移する
			if (order_list == null) {
				error = "カートの中に何も無かったので購入は出来ません。";
				cmd = "menu";
				return;
			}

			// 各DAOをインスタンス化し、関連メソッドをorder_listのカート追加データ分だけ呼び出す
			ProductDAO productDaoObj = new ProductDAO();
			OrderDAO orderDaoObj = new OrderDAO();
			ArrayList<Sales> product_list = new ArrayList<Sales>();


		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、購入は出来ません。";
			cmd = "logout";

		} finally {
			// ⑧ エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// エラーが無い場合はbuyConfirm.jspにフォワードする
				request.getRequestDispatcher("/view/buyConfirm.jsp").forward(
						request, response);
			} else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(
						request, response);
			}

		}
	}
}
