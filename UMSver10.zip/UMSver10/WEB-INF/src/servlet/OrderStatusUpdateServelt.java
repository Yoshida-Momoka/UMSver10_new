package servlet;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.*;
import dao.*;

public class OrderStatusUpdateServelt extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {

			// 文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			// DAOオブジェクト宣言
			OrderDAO ordDao = new OrderDAO();

			// 格納用オブジェクトを宣言
			Order order = new Order();
			User user = new User();

			// スコープを取得
			order = (Order) request.getAttribute("order_data");
			user = (User) request.getAttribute("user_data");
			String paymentStatus = (String) request.getParameter("payment");
			String shippingStatus = (String) request.getParameter("shipping");

			// orderオブジェクトへの格納
			order.setPaymentStatus(paymentStatus);
			order.setShippingStatus(shippingStatus);

			// updateメソッドを使って注文データをdbから更新
			ordDao.update(order);

			// メールを送信

			// 更新後の注文と顧客データをスコープに設定
			request.setAttribute("order_data", order);
			request.setAttribute("user_data", user);

		} catch (IllegalStateException e) {
			error = "DB接続エラーのため、注文状況更新が行えませんでした。";
		} catch (Exception e) {
			error = "予期せぬエラーが発生しました。<br>" + e;
		} finally {
			if (!error.equals("")) {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response); // error.jspにフォワード
			}
			request.getRequestDispatcher("/view/updateCompletion.jsp").forward(request, response); // updateCompletion.jspにフォワード
		}

	}
}