/*プログラム名：ユニフォーム受注管理システムWeb版 Ver1.0
プログラムの説明：	カート内に追加された
					商品情報、購入数を取得し、
					一覧を表示するプログラムです。
作成者：荻野早也佳
作成日：2024年1月31日*/
package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Order;
import bean.Product;
import bean.Sales;
import bean.User;
import dao.ProductDAO;

public class ShowCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";

		try {

			// 入力データの文字コードの指定
			request.setCharacterEncoding("UTF-8");

			// 削除対象のパラメータを取得
			String delno = request.getParameter("delno");

			// セッションのオブジェクトを生成
			HttpSession session = request.getSession();

			// セッションからユーザー情報とオーダーリストを取得
			User user = (User) session.getAttribute("user");
			ArrayList<Order> order_list = (ArrayList<Order>) session.getAttribute("order_list");

			// セッション切れか確認
			if (user == null) {
				// セッション切れならerror.jspへフォワード
				error = "セッション切れのため、カート情報は確認できません。";
				cmd = "logout";
				return;
			}

			// delnoがnullでなければ対象の情報を削除
			if (delno != null) {
				order_list.remove(Integer.parseInt(delno));
			}

			// ProductDAOをインスタンス化
			ProductDAO objProductDao = new ProductDAO();

			// Salesクラス型のArrayList配列を宣言
			ArrayList<Sales> product_list = new ArrayList<Sales>();

			// 商品情報を検索し、戻り値としてProductオブジェクトを取得する
			for (int i = 0; i < order_list.size(); i++) {
				Order order = order_list.get(i);
				Product product = objProductDao.selectByProductid(Integer.parseInt(order.getProductid()));
				// 取得した商品情報をProductクラスに格納し、product_listに追加
				Sales productinfo = new Sales(product, order.getQuantity());
				product_list.add(productinfo);
			}

			// リクエストスコープに"book_list"という名前で格納する
			request.setAttribute("product_list", product_list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、カート情報は確認できません。";
			cmd = "logaout";
		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.isEmpty()) {
				request.getRequestDispatcher("/view/showCart.jsp").forward(request, response);
			} else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
