package servlet;

/*プログラム名：ユニフォーム受注管理システム Ver1.0
プログラムの説明：	ログインしているユーザー情報に
					氏名、住所、メールアドレスを追加するプログラムです。
作成者：荻野早也佳
作成日：2024年1月30日*/

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.exceptions.MySQLSyntaxErrorException;

import bean.User;
import dao.UserDAO;

public class UserInfoInputServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {

			// セッションのオブジェクトを生成
			HttpSession session = request.getSession();

			// セッションからユーザー情報を取得
			User user = (User) session.getAttribute("user");

			// セッション切れか確認
			if (user == null) {
				// セッション切れならerror.jspへフォワード
				error = "セッション切れのため、ユーザー登録ができません。";
				cmd = "menu";
				return;
			}

			// ユーザーオブジェクト生成
			User newUser = new User();

			// DAOオブジェクト生成
			UserDAO objUserDao = new UserDAO();

			// 文字エンコーディング
			request.setCharacterEncoding("UTF-8");

			// パラメータの取得
			String userid = user.getUserid();
			String username = request.getParameter("username");
			String mailaddress = request.getParameter("mailaddress");
			String address = request.getParameter("address");

			cmd = request.getParameter("cmd");

			// 空文字チェック
			if (username.isEmpty()) {
				error = "ユーザー入力値不正のため、登録できません。";
				cmd = "menu";
			} else if (mailaddress.isEmpty()) {
				error = "メールアドレス入力値不正のため、登録できません。";
				cmd = "menu";
			} else if (address.isEmpty()) {
				error = "住所入力値不正のため、登録できません。";
				cmd = "menu";
			}

			// ユーザーオブジェクトに登録
			if (error.isEmpty()) {
				newUser.setUserid(userid);
				newUser.setUsername(username);
				newUser.setMailaddress(mailaddress);
				newUser.setAddress(address);

				// ユーザー登録メソッドを呼び出し
				objUserDao.insertByuserid(newUser);
			}

		} catch (IllegalStateException e) {
			// DB接続エラーの場合エラー画面にフォワード
			if (error.isEmpty()) {
				error = "DB接続エラーのためユーザー登録は行えません。";
				cmd = "menu";
			}

		} finally {
			if (error.isEmpty() && cmd.equals("registration")) {
				// 入力に問題がなく、ユーザー登録だけの場合メニュー画面にフォワード
				request.getRequestDispatcher("/view/menu.jsp").forward(request, response);

			} else if (error.isEmpty() && cmd.equals("buy")) {
				// 入力に問題がなく、購入に進む場合注文確認画面にフォワード
				request.getRequestDispatcher("/buyConfirm").forward(request, response);

			} else {
				// 入力に問題がある場合エラー画面にフォワード
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
