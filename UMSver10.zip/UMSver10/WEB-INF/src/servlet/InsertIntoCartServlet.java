package servlet;

/*プログラム名：ユニフォーム受注管理システム Ver1.0
プログラムの説明：	商品をカートに追加するプログラムです。
作成者：荻野早也佳
作成日：2024年1月30日*/

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Order;
import bean.Product;
import bean.User;
import dao.ProductDAO;

public class InsertIntoCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		String cmd = "";
		ArrayList<Order> list;

		try {
			// セッションのオブジェクトを生成
			HttpSession session = request.getSession();

			// セッションからユーザー情報を取得
			User user = (User) session.getAttribute("user");

			// セッション切れか確認
			if (user == null) {
				// セッション切れならerror.jspへフォワード
				error = "セッション切れのため、カートに追加できません。";
				cmd = "logout";
				return;
			}

			// 入力データの文字コードの指定
			request.setCharacterEncoding("UTF-8");

			// 商品ID、数量を取得
			String productid = request.getParameter("productid");
			int quantity = Integer.parseInt(request.getParameter("quantity"));

			// ProductDAOをインスタンス化
			ProductDAO objDao = new ProductDAO();

			// 情報を検索し、戻り値としてProductオブジェクトを取得する
			Product product = objDao.selectByProductid(Integer.parseInt(productid));

			// 購入数が在庫数を超えているか確認
			if (product.getStock() < quantity) {
				error = "購入数が在庫数を超えているため、カートに追加できません。";
				return;
			}

			// 数量をリクエストスコープに"quantity"という名前で格納する
			request.setAttribute("quantity", quantity);

			// 取得したproductをリクエストスコープに"product"という名前で格納する
			request.setAttribute("product", product);

			// Orderオブジェクトの生成と登録
			Order order = new Order();
			order.setProductid(String.valueOf(product.getProductid()));
			order.setUserid(user.getUserid());
			order.setQuantity(quantity);

			// セッションからList配列を取得する
			list = (ArrayList<Order>) session.getAttribute("order_list");

			// 取得できなかった場合（初回）
			if (list == null) {
				list = new ArrayList<Order>();
			}

			// order_list内に購入しようとしているユニフォーム（productid）がないかチェック
			int orderedQuantity = 0; // すでにカートに入っている場合の購入数を管理する変数
			for (int i = 0; i < list.size(); i++) {
				Order o = list.get(i);
				if (productid.equals(o.getProductid())) {
					// カート追加済みの場合、購入数のみをカート情報に加算
					o.setQuantity(o.getQuantity() + quantity);
					orderedQuantity = o.getQuantity();
				}
			}

			// 新規追加の場合、Orderオブジェクトをlistに追加
			if (orderedQuantity == 0) {
				list.add(order);
			}

			// セッションスコープに"order_list"の名前で登録
			session.setAttribute("order_list", list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、カートに追加はできません。";
			cmd = "logaout";

		} catch (NumberFormatException e) {
			// 購入数が未入力の場合のエラー文
			if (request.getParameter("quantity").isEmpty()) {
				error = "購入数が未入力の為、カートに追加はできません。";
			} else {
				// 購入数が文字列の場合のエラー文
				error = "購入数の値が不正の為、カートに追加はできません。";
			}

		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.isEmpty()) {
				request.getRequestDispatcher("/view/insertIntoCart.jsp").forward(request, response);
			} else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
