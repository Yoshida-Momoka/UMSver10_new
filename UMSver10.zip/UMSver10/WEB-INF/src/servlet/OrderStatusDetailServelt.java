package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Order;
import bean.User;
import dao.OrderDAO;
import dao.UserDAO;



/*
 *プログラム名  ：ユニフォーム発注管理システム
 *プログラム説明：「注文状況詳細」注文番号のリンクが押下された場合の処理を提供するサーブレット
 *作成者        ：小倉悠聖
 *作成日        ：2024年1月31日
 *変更履歴      ：STEP1 初期作成
*/

public class OrderStatusDetailServelt extends HttpServlet{
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException
	{
		try{
			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//オブジェクト宣言
			UserDAO objUserDao   = new UserDAO();
			User    objUsers = new User();
			OrderDAO objOrderDao   = new OrderDAO();
			Order    objOrders = new Order();

			//変数宣言
			String userid;
			String orderid;
			String cmd;

			//フォーム値を取得(userid,orderid,cmd)
			userid = request.getParameter("user");
			orderid = request.getParameter("order_data");
			cmd  = request.getParameter("cmd");

			//該当userid,orderidのデータ取得
			objUsers=objUserDao.selectByUser(userid);
			objOrders =objOrderDao.selectByOrderid(Integer.parseInt(orderid));

			//スコープのデータを登録
			request.setAttribute("user", objUsers);
			request.setAttribute("order_data", objOrders);

			//cmdの場所にフォワード
			request.getRequestDispatcher("/view/"+cmd+".jsp").forward(request, response);

		} catch (IllegalStateException e) {
			//エラー情報を持ってerror.jspにフォワード
			String error ="DB接続エラーの為、書籍詳細は表示できませんでした。";
			request.setAttribute("error", error);
			request.setAttribute("cmd", "menu");
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);

		} catch(Exception e){
			String error ="予期せぬエラーが発生しました。"+e;
			request.setAttribute("error", error);
			request.setAttribute("cmd", "menu");
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);

		}
	}
}
