package dao;

import java.util.*;
import java.sql.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Order;

public class OrderDAO {

	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost/kandauniformdb";
	private static final String USER = "root";
	private static final String PASSWD = "root123";

	// DBに接続を行うメソッド
	private static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/**
	 * 引数の購入データを基にDBのorderinfoテーブルに新規登録処理を行うメソッド定義
	 *
	 * @return なし
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	public void insert(Order order) {
		Connection con = null;
		Statement smt = null;
		int count = 0;

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "INSERT INTO orderinfo VALUES (null, '" + order.getUserid() + "', '" + order.getProductid()
					+ "', '" + order.getPaymentStatus() + "', '" + order.getShippingStatus() + "', "
					+ order.getQuantity() + ", '" + order.getTotal() + "', CURRENT_TIMESTAMP)";

			count = smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/**
	 * @メソッド名 ：selectAll
	 * @説明 ：全ての注文情報を取得する
	 * @args ：なし
	 * @return ：List型の配列
	 */
	public ArrayList<Order> selectAll() {
		// 配列宣言
		ArrayList<Order> list = new ArrayList<Order>();
		// SQL文
		String sql = "SELECT * FROM orderinfo ORDER BY orderid";

		Connection con = null;
		Statement smt = null;
		try {
			// DBに接続
			con = OrderDAO.getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果を配列に格納
			while (rs.next()) {
				Order orders = new Order();
				orders.setOrderid(rs.getInt("orderid"));
				orders.setOrderdate(rs.getString("orderdate"));
				orders.setUserid(rs.getString("userid"));
				orders.setTotal(rs.getString("total"));
				orders.setPaymentStatus(rs.getString("paymentStatus"));
				orders.setShippingStatus(rs.getString("shippingStatus"));

				list.add(orders);
			}

		} catch (SQLException e) {
			System.out.println("Errorが発生しました！\n" + e);
			throw new IllegalStateException(e);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return list;
	}


	/**
	 * @メソッド名	 ：selectByOrderid
	 * @説明		 ：注文IDからデータを取得する
	 * @param 	orderid ：orderid
	 * @return	order：Order型のオブジェクト
	 */
	public Order selectByOrderid(int orderid){
		//SQL文
		String sql = "SELECT * FROM productinfo WHERE orderid ='" + orderid + "'";

		//オブジェクト宣言
		Order order = new Order();

		//変数宣言
		Connection con = null;
		Statement  smt = null;

		try{
			//DBに接続
			con = OrderDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			while(rs.next()){
				//検索結果を配列に格納
				order.setOrderid(rs.getInt("orderid"));
				order.setPaymentStatus(rs.getString("paymentStatus"));
				order.setShippingStatus(rs.getString("shippingStatus"));
				order.setQuantity(rs.getInt("quantity"));
				order.setTotal(rs.getString("total"));
				order.setOrderdate(rs.getString("orderdate"));
			}
		}catch(SQLException e){
			System.out.println("Errorが発生しました！\n"+e);
			throw new IllegalStateException(e);
		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			//リソースの開放
			if(smt != null){
				try{smt.close();}catch(SQLException ignore){}
			}
			if(con != null){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return order;
	}

		/**
	 * 引数の注文データを基にDBのorderinfoテーブルにステータス更新処理を行うメソッド定義
	 *
	 * @return なし
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	public void update(Order order) {

		Connection con = null;
		Statement smt = null;

		try {

			String sql = "UPDATE orderinfo SET payment status = '" + order.getPaymentStatus() + "', shipping status= " + order.getShippingStatus()
					+ " WHERE orderid = '" + order.getOrderid() + "';";

			con = getConnection(); // DBに接続
			smt = con.createStatement();

			smt.executeUpdate(sql);// SQL文を実行

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}





}
