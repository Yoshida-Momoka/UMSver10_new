package bean;

import java.util.*;

public class Sales {

	// 売上IDを格納する変数
	private int salesid;

	//注文IDを格納する変数
	private int orderid;

	//商品IDを格納する変数
	private int productid;

	//商品名を格納する変数
	private String productname;

	//商品の金額を格納する変数
	private int price;

	//購入個数を格納する変数
	private int quantity;

	//合計金額を格納する変数
	private int total;

	//注文日時を格納する変数
	private Date orderdate;

	// 売上日時を格納する変数
	private Date salesdate;

	//コンストラクタ（引数なし）
	public Sales() {
		this.salesid = 0;
		this.orderid = 0;
		this.productid = 0;
		this.productname = null;
		this.price = 0;
		this.quantity = 0;
		this.total = 0;
		this.orderdate = null;
		this.salesdate = null;
	}

	//コンストラクタ（引数あり）
	public Sales(Product product,int quantity) {
		this.productid = product.getProductid();
		this.productname = product.getProductname();
		this.price = product.getPrice();
		this.quantity = quantity;
	}

	// アクセサメソッド

	public int getSalesid() {
		return salesid;
	}

	public void setSalesid(int salesid) {
		this.salesid = salesid;
	}

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total=total;
	}

	public Date getSalesdate() {
		return salesdate;
	}

	public void setSalesdate(Date salesdate) {
		this.salesdate = salesdate;
	}

	public Date getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}

}